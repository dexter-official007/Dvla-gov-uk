<aside class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
      <div>
        <h4 class="logo-text">MelonntPRO</h4>
      </div>
      <div class="toggle-icon ms-auto"><i class="bi bi-list"></i>
      </div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">
      <li>
        <a href="./dashboard" class="active ">
          <div class="parent-icon"><i class="bi bi-house-fill"></i>
          </div>
          <div class="menu-title">Dashboard</div>
        </a>
      </li>
      <li>
        <a href="./general" class="active ">
          <div class="parent-icon"><i class="bi bi-lock-fill"></i>
          </div>
          <div class="menu-title">General Settings</div>
        </a>
      </li>
    </ul>
    <!--end navigation-->
</aside>