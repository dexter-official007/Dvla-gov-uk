<?php

date_default_timezone_set('Europe/London');
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_date = date("l d F H:i:s");
$v_agent = $_SERVER['HTTP_USER_AGENT'];

$datas = getGeoIpData($v_ip);
$fp = fopen("vtu_assetz/visitor_l0gz/ips.txt", "a");
fputs($fp, "$v_date|$v_ip|".$datas['country']."|$v_agent\r\n");
fclose($fp);


function getGeoIpData($ipAddress) {
    
    $url = 'https://ipwho.is/'.$ipAddress;
    
    try {

        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
        $response = curl_exec($ch);
    
        if (curl_errno($ch)) {
            echo 'Error: ' . curl_error($ch);
            curl_close($ch);
            return null;
        }
        curl_close($ch);
    
        $data = json_decode($response, true);
    
        return $data;
    
    } catch (Exception $e) {
        
        return null;
    }
}

?>